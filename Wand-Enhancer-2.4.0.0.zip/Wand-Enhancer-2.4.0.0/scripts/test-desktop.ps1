param(
    [Parameter(Mandatory = $true)]
    [string]$AssemblyPath,
    [switch]$ExpectUpdateNotifications
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$assembly = [Reflection.Assembly]::LoadFrom((Resolve-Path -LiteralPath $AssemblyPath).Path)
$privateStatic = [Reflection.BindingFlags]'NonPublic, Static'
$privateInstance = [Reflection.BindingFlags]'NonPublic, Instance'

function Assert-Equal($Actual, $Expected, [string]$Message) {
    if ($Actual -ne $Expected) { throw "$Message (expected $Expected, got $Actual)" }
}

$supervisedNamespace = 'WandEnhancer.Core.Patching.Strategies.Supervised'
foreach ($typeName in 'MemoryFuseApplicator', 'ProcessInfo') {
    $type = $assembly.GetType("$supervisedNamespace.$typeName", $true)
    $methods = @($type.GetMethods($privateStatic) | Where-Object { $_.Name -in 'ReadProcessMemory', 'WriteProcessMemory' })
    $expectedMethodCount = if ($typeName -eq 'MemoryFuseApplicator') { 2 } else { 1 }
    Assert-Equal $methods.Count $expectedMethodCount "$typeName native memory methods"
    foreach ($method in $methods) {
        $parameters = $method.GetParameters()
        Assert-Equal $parameters[3].ParameterType ([UIntPtr]) "$typeName.$($method.Name) size"
        Assert-Equal $parameters[4].ParameterType ([UIntPtr].MakeByRefType()) "$typeName.$($method.Name) byte count"
    }
}

$updateNotifier = $assembly.GetType('WandEnhancer.Core.UpdateNotifier', $false)
Assert-Equal ($null -ne $updateNotifier) ([bool]$ExpectUpdateNotifications) 'Compile-time update notifier'
if ($ExpectUpdateNotifications) {
    $isNewerVersion = $updateNotifier.GetMethod('IsNewerVersion', $privateStatic)
    $current = $assembly.GetName().Version
    $newer = [Version]::new($current.Major, $current.Minor, $current.Build, $current.Revision + 1)
    Assert-Equal ($isNewerVersion.Invoke($null, @($newer.ToString()))) $true 'Newer release detection'
    Assert-Equal ($isNewerVersion.Invoke($null, @("v$current"))) $false 'Current release detection'
    Assert-Equal ($isNewerVersion.Invoke($null, @('invalid'))) $false 'Invalid release detection'

    $buildNotificationText = $updateNotifier.GetMethod('BuildNotificationText', $privateStatic)
    $notificationText = $buildNotificationText.Invoke($null, @("### Fixes`n- Fixed launch"))
    Assert-Equal ($notificationText.Contains('Fixed launch')) $true 'Release note notification'

    $appSettings = [Activator]::CreateInstance($assembly.GetType('WandEnhancer.Core.Services.AppSettings', $true))
    Assert-Equal $appSettings.CheckUpdates $true 'Update check default enabled'
    Assert-Equal $appSettings.CheckPrereleases $false 'Prerelease check default disabled'

    $vmType = $assembly.GetType('WandEnhancer.View.MainWindow.MainWindowVm', $true)
    Assert-Equal ($null -ne $vmType.GetProperty('IsUpdateAvailable')) $true 'Header update badge property'
    Assert-Equal ($null -ne $vmType.GetProperty('ShowUpdateCommand')) $true 'Header update badge command'
}

$scratch = Join-Path ([IO.Path]::GetTempPath()) ('wand-desktop-test-' + [guid]::NewGuid().ToString('N'))
$install = Join-Path $scratch 'app-1.0.0'
$resources = Join-Path $install 'resources'
[IO.Directory]::CreateDirectory($resources) | Out-Null

try {
    $enhancerType = $assembly.GetType('WandEnhancer.Core.Enhancer', $true)
    $isPatched = $enhancerType.GetMethod('IsPatched')
    $hasBackup = $enhancerType.GetMethod('HasBackup')
    $backup = Join-Path $resources 'app.asar.backup'
    $unpackedBackup = Join-Path $resources 'app.asar.unpacked.backup'
    $markerName = $enhancerType.GetField('IncompletePatchMarkerFileName', $privateStatic).GetRawConstantValue()
    $marker = Join-Path $resources $markerName
    $asar = Join-Path $resources 'app.asar'
    $unpacked = Join-Path $resources 'app.asar.unpacked'

    $installArgument = [object[]]@([string]$install)
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $false 'Fresh installation'
    [IO.File]::WriteAllText($backup, 'original archive')
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $false 'Incomplete backup'
    [IO.Directory]::CreateDirectory($unpackedBackup) | Out-Null
    [IO.File]::WriteAllText((Join-Path $unpackedBackup 'original.txt'), 'original unpacked')
    Assert-Equal ($hasBackup.Invoke($null, $installArgument)) $true 'Complete backup'
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $true 'Legacy complete backups'
    [IO.File]::WriteAllText($marker, '')
    Assert-Equal ($hasBackup.Invoke($null, $installArgument)) $true 'Restorable unfinished patch'
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $false 'Unfinished patch'

    $config = [Activator]::CreateInstance($assembly.GetType('WandEnhancer.Models.WeModConfig', $true))
    $config.RootDirectory = $install
    $config.ExecutableName = 'FixtureClient.exe'
    $config.BrandName = 'wand-test-' + [guid]::NewGuid().ToString('N')
    $logType = $assembly.GetType('WandEnhancer.Core.ELogType', $true)
    $loggerType = [Action``2].MakeGenericType([string], $logType)
    $logger = { param($message, $level) } -as $loggerType
    $enhancer = [Activator]::CreateInstance($enhancerType, @($config, $logger))
    $rollback = $enhancerType.GetMethod('RollbackQuietly', $privateInstance)

    [IO.File]::WriteAllText($asar, 'partial archive')
    [IO.Directory]::CreateDirectory($unpacked) | Out-Null
    [IO.File]::WriteAllText((Join-Path $unpacked 'injected.txt'), 'partial injection')
    $rollback.Invoke($enhancer, $null) | Out-Null
    Assert-Equal ([IO.File]::ReadAllText($asar)) 'original archive' 'Rollback archive'
    Assert-Equal ([IO.File]::ReadAllText((Join-Path $unpacked 'original.txt'))) 'original unpacked' 'Rollback unpacked files'
    Assert-Equal (Test-Path (Join-Path $unpacked 'injected.txt')) $false 'Rollback injection removal'
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $false 'Rolled-back installation'
    Assert-Equal (Test-Path $backup) $true 'Rollback preserves archive backup'
    Assert-Equal (Test-Path $unpackedBackup) $true 'Rollback preserves unpacked backup'

    [IO.File]::Delete($marker)
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $true 'Completed retry'
    [IO.File]::WriteAllText($marker, '')
    [IO.File]::WriteAllText((Join-Path $scratch 'FixtureClient.exe.stub'), 'original launcher')
    $autoPatchConfig = Join-Path $scratch ($assembly.GetType('WandEnhancer.Constants', $true).GetField('AutoPatchConfigFileName').GetRawConstantValue())
    foreach ($path in $autoPatchConfig, (Join-Path $scratch 'launcher.log'), (Join-Path $scratch 'launcher.prev.log')) {
        [IO.File]::WriteAllText($path, 'fixture')
    }
    $watcherExe = Join-Path $scratch 'WandEnhancerWatcher.exe'
    [IO.File]::WriteAllText($watcherExe, 'fixture')

    # Restore can only target this fixture's unique process name and scratch Squirrel root.
    Assert-Equal ([Diagnostics.Process]::GetProcessesByName($config.BrandName).Length) 0 'Fixture process isolation'
    $enhancerType.GetMethod('Restore').Invoke($enhancer, $null) | Out-Null
    foreach ($path in $backup, $unpackedBackup, $marker) {
        Assert-Equal (Test-Path $path) $false 'Restore clears patch state'
    }
    Assert-Equal ([IO.File]::ReadAllText((Join-Path $scratch 'FixtureClient.exe'))) 'original launcher' 'Restore launcher'
    Assert-Equal (Test-Path $autoPatchConfig) $false 'Restore removes auto-patch config'
    Assert-Equal (Test-Path $watcherExe) $false 'Restore removes the deployed watcher exe'
    foreach ($log in 'launcher.log', 'launcher.prev.log') {
        Assert-Equal (Test-Path (Join-Path $scratch $log)) $true "Restore keeps $log"
    }
    Assert-Equal ($isPatched.Invoke($null, $installArgument)) $false 'Restored installation'

    # A watcher exe still locked by its exiting process must not fail an otherwise complete Restore.
    [IO.File]::WriteAllText($backup, 'original archive')
    [IO.Directory]::CreateDirectory($unpackedBackup) | Out-Null
    [IO.File]::WriteAllText((Join-Path $unpackedBackup 'original.txt'), 'original unpacked')
    [IO.File]::WriteAllText($watcherExe, 'fixture')
    $watcherLock = [IO.File]::Open($watcherExe, 'Open', 'Read', 'None')
    try {
        $enhancerType.GetMethod('Restore').Invoke($enhancer, $null) | Out-Null
    }
    finally {
        $watcherLock.Dispose()
    }
    Assert-Equal (Test-Path $backup) $false 'Restore completes while the watcher exe is locked'
    Assert-Equal (Test-Path $watcherExe) $true 'A locked watcher exe is left in place'

    # A lock while restoring the pristine files must trigger the rollback, not leave a half-emptied tree.
    [IO.File]::WriteAllText($asar, 'original archive')
    [IO.File]::WriteAllText($backup, 'original archive')
    [IO.Directory]::CreateDirectory($unpackedBackup) | Out-Null
    [IO.File]::WriteAllText((Join-Path $unpackedBackup 'original.txt'), 'original unpacked')
    [IO.Directory]::CreateDirectory($unpacked) | Out-Null
    $lockedFile = Join-Path $unpacked 'locked.dll'
    [IO.File]::WriteAllText($lockedFile, 'in use')
    $messages = [Collections.Generic.List[string]]::new()
    $recordingLogger = ({ param($message, $level) $messages.Add($message) }.GetNewClosure()) -as $loggerType
    $patchConfig = [Activator]::CreateInstance($assembly.GetType('WandEnhancer.Models.PatchConfig', $true))
    $lockedEnhancer = [Activator]::CreateInstance($enhancerType, @($config, $recordingLogger, $patchConfig))
    $lock = [IO.File]::Open($lockedFile, 'Open', 'Read', 'None')
    try {
        $failed = $false
        try { $enhancerType.GetMethod('Patch').Invoke($lockedEnhancer, $null) | Out-Null } catch { $failed = $true }
        Assert-Equal $failed $true 'Locked preparation fails Patch'
    }
    finally {
        $lock.Dispose()
    }
    $rolledBack = @($messages | Where-Object { $_ -like '*rollback did not finish*' -or $_ -like '*original Wand files were restored*' })
    Assert-Equal ($rolledBack.Count -gt 0) $true 'Locked preparation triggers rollback'

    # A service the pristine install had must not silently vanish (antivirus) and still report success.
    $ensureSurvived = $assembly.GetType('WandEnhancer.Core.Patching.Shared.AuxiliaryCompatibility', $true).GetMethod('EnsureSurvivedPatching')
    $pristineTree = Join-Path $scratch 'pristine-tree'
    $liveTree = Join-Path $scratch 'live-tree'
    foreach ($tree in $pristineTree, $liveTree) {
        [IO.Directory]::CreateDirectory((Join-Path $tree 'static\unpacked\auxiliary')) | Out-Null
    }
    $trees = [object[]]@([string]$pristineTree, [string]$liveTree)
    $ensureSurvived.Invoke($null, $trees) | Out-Null
    $pristineService = Join-Path $pristineTree 'static\unpacked\auxiliary\FixtureAuxiliaryService.exe'
    [IO.File]::WriteAllText($pristineService, 'service')
    $vanished = $false
    try { $ensureSurvived.Invoke($null, $trees) | Out-Null } catch { $vanished = $true }
    Assert-Equal $vanished $true 'Quarantined auxiliary service fails Patch'
    [IO.File]::WriteAllText((Join-Path $liveTree 'static\unpacked\auxiliary\FixtureAuxiliaryService.exe'), 'service')
    $ensureSurvived.Invoke($null, $trees) | Out-Null
    $secondService = 'SecondAuxiliaryService.exe'
    [IO.File]::WriteAllText((Join-Path $pristineTree "static\unpacked\auxiliary\$secondService"), 'service2')
    $vanished = $false
    try { $ensureSurvived.Invoke($null, $trees) | Out-Null } catch { $vanished = $true }
    Assert-Equal $vanished $true 'Quarantine of any auxiliary service among multiple fails Patch'
    [IO.File]::WriteAllText((Join-Path $liveTree "static\unpacked\auxiliary\$secondService"), 'service2')
    $ensureSurvived.Invoke($null, $trees) | Out-Null

    # The Squirrel root must be swept too: a bystander child under it locks the folder during updates.
    $bystander = Join-Path $scratch 'Bystander.exe'
    Copy-Item -LiteralPath (Join-Path $env:SystemRoot 'System32\cmd.exe') -Destination $bystander -Force
    $bystanderProcess = Start-Process -FilePath $bystander -ArgumentList '/c', 'pause' -WindowStyle Hidden -PassThru
    try {
        $killInstallProcesses = $enhancerType.GetMethod('KillInstallProcesses', $privateInstance)
        $killInstallProcesses.Invoke($enhancer, $null) | Out-Null
        Assert-Equal $bystanderProcess.HasExited $false 'Non-Squirrel parent is not swept'
        [IO.File]::WriteAllText((Join-Path $scratch 'Update.exe'), '')
        $killInstallProcesses.Invoke($enhancer, $null) | Out-Null
        $bystanderProcess.WaitForExit(5000) | Out-Null
        Assert-Equal $bystanderProcess.HasExited $true 'Squirrel root is swept'
    }
    finally {
        if (-not $bystanderProcess.HasExited) { $bystanderProcess.Kill() }
    }

    # Squirrel keeps writing while its updater runs, so a stable app.asar must not count as "done" until it exits.
    $waitForSettled = $assembly.GetType('WandEnhancer.Core.Services.UpdateWatcherService', $true).GetMethod('WaitForSettled', $privateStatic)
    [IO.File]::WriteAllText($asar, 'stable archive')
    $updaterPath = Join-Path $scratch 'Update.exe'
    Copy-Item -LiteralPath (Join-Path $env:SystemRoot 'System32\cmd.exe') -Destination $updaterPath -Force
    $updater = Start-Process -FilePath $updaterPath -ArgumentList '/c', 'pause' -WindowStyle Hidden -PassThru
    $stopUpdater = Start-Job -ScriptBlock { param($id) Start-Sleep -Seconds 5; Stop-Process -Id $id -Force } -ArgumentList $updater.Id
    try {
        $clock = [Diagnostics.Stopwatch]::StartNew()
        $settled = $waitForSettled.Invoke($null, [object[]]@([string]$install, [string]$scratch))
        $clock.Stop()
        Assert-Equal $settled $true 'Watcher settles once the updater exits'
        Assert-Equal ($clock.Elapsed.TotalSeconds -gt 10) $true 'Watcher waits for a running updater'
    }
    finally {
        if (-not $updater.HasExited) { $updater.Kill() }
        Remove-Job -Job $stopUpdater -Force
    }

    # A picked or dropped folder may be the version folder or the Squirrel root that holds it.
    $resolveInstall = $assembly.GetType('WandEnhancer.Utils.WeModInstalls', $true).GetMethod('ResolveInstall')
    $squirrelRoot = Join-Path $scratch 'drop-root'
    $versionFolder = Join-Path $squirrelRoot 'app-2.0.0'
    [IO.Directory]::CreateDirectory((Join-Path $versionFolder 'resources')) | Out-Null
    [IO.File]::WriteAllText((Join-Path $versionFolder 'Wand.exe'), '')
    [IO.File]::WriteAllText((Join-Path $versionFolder 'resources\app.asar'), '')
    foreach ($candidate in $versionFolder, $squirrelRoot) {
        $resolved = $resolveInstall.Invoke($null, [object[]]@([string]$candidate))
        Assert-Equal ($null -ne $resolved) $true "Resolves $candidate"
        Assert-Equal $resolved.RootDirectory $versionFolder "Resolved root for $candidate"
    }

    # Re-detect moves to the newest install of the root, and keeps a hand-picked folder that is not an app-* folder.
    $rescan = $assembly.GetType('WandEnhancer.Utils.WeModInstalls', $true).GetMethod('Rescan')
    $configType = $assembly.GetType('WandEnhancer.Models.WeModConfig', $true)
    function Invoke-Rescan([string]$Root, [string]$InstallFolder) {
        $target = [Activator]::CreateInstance($configType)
        $target.RootDirectory = $InstallFolder
        $rescan.Invoke($null, [object[]]@($Root, $target))
    }
    $olderFolder = Join-Path $squirrelRoot 'app-1.0.0'
    $portableRoot = Join-Path $scratch 'portable'
    $portable = Join-Path $portableRoot 'Wand'
    foreach ($folder in $olderFolder, $portable) {
        [IO.Directory]::CreateDirectory((Join-Path $folder 'resources')) | Out-Null
        [IO.File]::WriteAllText((Join-Path $folder 'Wand.exe'), '')
        [IO.File]::WriteAllText((Join-Path $folder 'resources\app.asar'), '')
    }
    $newest = Invoke-Rescan $squirrelRoot $olderFolder
    Assert-Equal ($null -ne $newest -and $newest.RootDirectory -eq $versionFolder) $true 'Rescan moves to the newest install'
    $kept = Invoke-Rescan $portableRoot $portable
    Assert-Equal ($null -ne $kept -and $kept.RootDirectory -eq $portable) $true 'Rescan keeps a valid hand-picked folder'
    Assert-Equal ($null -eq (Invoke-Rescan $portableRoot (Join-Path $portableRoot 'Gone'))) $true 'Rescan drops an install that is gone'
    $unrelated = Join-Path $scratch 'unrelated'
    [IO.Directory]::CreateDirectory($unrelated) | Out-Null
    foreach ($candidate in $unrelated, (Join-Path $scratch 'missing-folder')) {
        Assert-Equal ($null -eq $resolveInstall.Invoke($null, [object[]]@([string]$candidate))) $true "Rejects $candidate"
    }

    # Squirrel keeps the previous version folder and a scan or backup write makes it look newer: rank by version, not mtime.
    $rankRoot = Join-Path $scratch 'rank-root'
    foreach ($name in 'app-12.9.0', 'app-12.10.0') {
        $folder = Join-Path $rankRoot $name
        [IO.Directory]::CreateDirectory((Join-Path $folder 'resources')) | Out-Null
        [IO.File]::WriteAllText((Join-Path $folder 'Wand.exe'), '')
        [IO.File]::WriteAllText((Join-Path $folder 'resources\app.asar'), '')
    }
    (Get-Item -LiteralPath (Join-Path $rankRoot 'app-12.9.0')).LastWriteTime = (Get-Date).AddHours(1)
    $latest = $resolveInstall.Invoke($null, [object[]]@([string]$rankRoot))
    Assert-Equal $latest.RootDirectory (Join-Path $rankRoot 'app-12.10.0') 'Latest install is the highest version, not the newest folder'
    $parseFolderVersion = $assembly.GetType('WandEnhancer.Utils.WeModInstalls', $true).GetMethod('ParseFolderVersion')
    $v2part = $parseFolderVersion.Invoke($null, [object[]]@('app-12.10'))
    $v3part = $parseFolderVersion.Invoke($null, [object[]]@('app-12.10.0'))
    Assert-Equal ($v2part.CompareTo($v3part)) 0 'app-12.10 and app-12.10.0 compare equal'
    Write-Host 'Desktop regression checks passed (native sizes, backups, rollback, retry state, restore).'
}
finally {
    Remove-Item -LiteralPath $scratch -Recurse -Force
}
