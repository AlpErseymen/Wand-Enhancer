using System;
using System.IO;
using System.Linq;
using WandEnhancer.Core.Patching.Strategies;
using WandEnhancer.Core.Patching.Strategies.Static;

namespace WandEnhancer.Core.Patching.Shared
{
    internal static class AuxiliaryCompatibility
    {
        private static string[] FindAll(string unpackedPath)
        {
            string directory = string.IsNullOrEmpty(unpackedPath) ? null
                : Path.Combine(unpackedPath, @"static\unpacked\auxiliary");
            return directory != null && Directory.Exists(directory)
                ? Directory.EnumerateFiles(directory, "*AuxiliaryService.exe").ToArray()
                : new string[0];
        }

        /// <summary>
        /// A missing service is skipped as "this install has none", so one quarantined mid-patch would
        /// otherwise leave a patch that reports success without it.
        /// </summary>
        public static void EnsureSurvivedPatching(string pristineUnpackedPath, string patchedUnpackedPath)
        {
            var pristine = new System.Collections.Generic.HashSet<string>(
                FindAll(pristineUnpackedPath).Select(Path.GetFileName),
                StringComparer.OrdinalIgnoreCase);
            var patched = new System.Collections.Generic.HashSet<string>(
                FindAll(patchedUnpackedPath).Select(Path.GetFileName),
                StringComparer.OrdinalIgnoreCase);

            foreach (var name in pristine)
            {
                if (!patched.Contains(name))
                {
                    throw new FileNotFoundException("[ENHANCER] The auxiliary service disappeared while patching. " +
                                                    "Antivirus probably quarantined it: add an exclusion for the Wand folder and patch again.");
                }
            }
        }

        public static void Apply(PatchContext context)
        {
            string[] auxiliaries = FindAll(context.UnpackedPath);
            if (auxiliaries.Length == 0)
            {
                context.Log?.Invoke("[ENHANCER] No auxiliary service found; skipping compatibility checks.", ELogType.Info);
                return;
            }

            foreach (string auxiliary in auxiliaries)
            {
                if (AuxTrustNeutralizer.Neutralize(auxiliary, context.Log) < 0)
                {
                    throw new InvalidDataException(string.Format("[ENHANCER] Unsupported auxiliary service ({0}); it would reject the patched Wand.", Path.GetFileName(auxiliary)));
                }
            }
        }
    }
}
