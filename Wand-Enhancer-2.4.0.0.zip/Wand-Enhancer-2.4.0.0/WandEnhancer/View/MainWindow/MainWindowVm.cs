using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using WandEnhancer.Core;
using WandEnhancer.Core.Services;
using WandEnhancer.Models;
using WandEnhancer.ReactiveUICore;
using WandEnhancer.Utils;
using WandEnhancer.View.Popups;
using Application = System.Windows.Application;

namespace WandEnhancer.View.MainWindow
{
    public class MainWindowVm : ObservableObject
    {
        private const string LogExportFilter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

        private readonly IShellView _shell;
        private readonly IFileDialogs _dialogs;
        public ObservableCollection<LogEntry> LogList { get; } = new ObservableCollection<LogEntry>();
        private WeModConfig _weModConfig;

        public WeModConfig WeModInfo
        {
            get => _weModConfig;
            set => SetProperty(ref _weModConfig, value);
        }

        private void UseInstall(WeModConfig config)
        {
            WeModInfo = config;
            if (config == null)
            {
                AlreadyPatched = false;
                CanRestore = false;
                IsPatchEnabled = false;
                return;
            }

            Log(LocalizationManager.Format("log_install_found", config, config.ExecutableName), ELogType.Success);
            AlreadyPatched = Enhancer.IsPatched(config.RootDirectory);
            CanRestore = Enhancer.HasBackup(config.RootDirectory);
            IsPatchEnabled = !AlreadyPatched;

            Log(LocalizationManager.Get(AlreadyPatched ? "log_already_patched" : "log_ready"),
                AlreadyPatched ? ELogType.Warn : ELogType.Info);

            string parent = Directory.GetParent(config.RootDirectory)?.FullName;
            string installRoot = !string.IsNullOrEmpty(parent) && File.Exists(Path.Combine(parent, "Update.exe"))
                ? parent
                : config.RootDirectory;

            var settings = SettingsManager.LoadSettings() ?? new AppSettings();
            if (settings.LastInstallPath != installRoot)
            {
                settings.LastInstallPath = installRoot;
                SettingsManager.SaveSettings(settings);
            }

            try
            {
                var newer = WeModInstalls.FindNewerInstall(installRoot, config);
                if (newer != null)
                {
                    Log(LocalizationManager.Format("log_newer_version",
                        Path.GetFileName(newer.RootDirectory), newer.RootDirectory), ELogType.Warn);
                }
            }
            catch
            {
                // Ignore errors checking for newer install.
            }
        }

        private bool _isPatchEnabled;

        public bool IsPatchEnabled
        {
            get => _isPatchEnabled;
            set
            {
                if (SetProperty(ref _isPatchEnabled, value))
                {
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        private bool _alreadyPatched;

        public bool AlreadyPatched
        {
            get => _alreadyPatched;
            set
            {
                if (SetProperty(ref _alreadyPatched, value))
                {
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        private bool _canRestore;

        public bool CanRestore
        {
            get => _canRestore;
            set
            {
                if (SetProperty(ref _canRestore, value))
                {
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        private bool _isBusy;

        /// <summary>True while a patch or restore runs.</summary>
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                {
                    OnPropertyChanged(nameof(IsIdle));
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        /// <summary>Bound by buttons that must not be clickable mid-run.</summary>
        public bool IsIdle => !_isBusy;

        public RelayCommand SetFolderPathCommand { get; }
        public RelayCommand ApplyPatchCommand { get; }
        public RelayCommand RestoreBackupCommand { get; }
        public RelayCommand OpenSettingsCommand { get; }
        public RelayCommand CopyLogsCommand { get; }
        public RelayCommand ExportLogsCommand { get; }
        public RelayCommand ConfigureFirewallCommand { get; }
        public RelayCommand RunDiagnosticsCommand { get; }
        public RelayCommand RunAutoDoctorCommand { get; }
        public RelayCommand CopyDiagnosticsCommand { get; }
        public RelayCommand RescanInstallCommand { get; }

        private bool _isResolvingInstall;

        /// <summary>
        /// Picks the install from a folder or from the Wand executable inside one. Ignored while a run or
        /// another pick is active: the install must not change under them.
        /// </summary>
        public Task UseInstallPathAsync(string path) =>
            PickInstallAsync(
                () => WeModInstalls.ResolveInstall(File.Exists(path) ? Path.GetDirectoryName(path) : path),
                () => Log(LocalizationManager.Format("log_invalid_directory", Path.GetFileName(path)), ELogType.Error));

        private async Task PickInstallAsync(Func<WeModConfig> resolve, Action onMissing)
        {
            if (IsBusy || _isResolvingInstall)
            {
                return;
            }

            _isResolvingInstall = true;
            try
            {
                // Off the UI thread: a network share or a large folder must not freeze the window, or Explorer waiting on the drop.
                var info = await Task.Run(resolve);
                if (IsBusy)
                {
                    return;
                }

                if (info == null)
                {
                    onMissing();
                    return;
                }

                UseInstall(info);
            }
            finally
            {
                _isResolvingInstall = false;
            }
        }

        public void SetCustomInstallPath(string selectedPath)
        {
            if (string.IsNullOrWhiteSpace(selectedPath)) return;
            _ = UseInstallPathAsync(selectedPath);
        }

        private void OnFolderPathSelection(object obj)
        {
            string selectedPath = _dialogs.PickFolder(
                LocalizationManager.Get("dialog_pick_install"),
                Environment.GetEnvironmentVariable("LOCALAPPDATA"));
            if (selectedPath == null)
            {
                return;
            }

            SetCustomInstallPath(selectedPath);
        }

        /// <summary>
        /// Runs <paramref name="runWork"/> directly if Wand isn't running. Otherwise asks for
        /// explicit confirmation before force-closing it - Patch/Restore force-close Wand
        /// themselves once invoked, but used to do so unconditionally with no way to decline.
        /// </summary>
        private void RunRequiringWandClosed(Func<Task> runWork)
        {
            if (WeModInfo == null || !ProcessTerminator.IsRunning(WeModInfo.BrandName))
            {
                _ = runWork();
                return;
            }

            _shell.OpenPopup(new CloseWandConfirmPopup(WeModInfo.BrandName, () =>
            {
                _shell.ClosePopup();
                _ = runWork();
            }), LocalizationManager.Get("cwc_popup_title"));
        }

        // Runs off the UI thread due to heavy file IO.
        private void OnBackupRestoring(object param)
        {
            if (WeModInfo == null)
            {
                Log(LocalizationManager.Get("log_no_directory"), ELogType.Warn);
                return;
            }

            RunRequiringWandClosed(async () =>
            {
                IsBusy = true;
                bool restored = await Task.Run(() =>
                {
                    try
                    {
                        new Enhancer(WeModInfo, Log).Restore();
                        return true;
                    }
                    catch (Exception e)
                    {
                        Log(LocalizationManager.Format("log_restore_failed", e.Message), ELogType.Error);
                        return false;
                    }
                });

                IsBusy = false;
                if (restored)
                {
                    AlreadyPatched = false;
                    CanRestore = false;
                    IsPatchEnabled = true;
                }
            });
        }

        private void OnPatching(object param)
        {
            if (WeModInfo == null)
            {
                Log(LocalizationManager.Get("log_no_directory"), ELogType.Warn);
                return;
            }

            var saved = SettingsManager.LoadSettings()?.LastPatchConfig;
            _shell.OpenPopup(new PatchVectorsPopup(config =>
            {
                _shell.ClosePopup();
                RunRequiringWandClosed(async () =>
                {
                    IsPatchEnabled = false;
                    IsBusy = true;

                    var settings = SettingsManager.LoadSettings() ?? new AppSettings();
                    settings.LastPatchConfig = config;
                    SettingsManager.SaveSettings(settings);

                    await Task.Run(() =>
                    {
                        try
                        {
                            new Enhancer(WeModInfo, Log, config).Patch();
                            AlreadyPatched = true;
                            CanRestore = true;
                        }
                        catch (Exception e)
                        {
                            Log(LocalizationManager.Format("log_patch_failed", e.Message), ELogType.Error);
                            IsPatchEnabled = true;
                        }
                    });
                    IsBusy = false;
                });
            }, saved), LocalizationManager.Get("pv_popup_title"));
        }

        // The current install first, so a manually picked one is rescanned too; the default locations only when it is gone.
        private async void OnRescanInstall(object param)
        {
            var current = WeModInfo;
            string parent = current != null ? Directory.GetParent(current.RootDirectory)?.FullName : null;
            string rescanRoot = !string.IsNullOrEmpty(parent) && File.Exists(Path.Combine(parent, "Update.exe"))
                ? parent
                : current?.RootDirectory;

            await PickInstallAsync(
                () => (rescanRoot != null && current != null ? WeModInstalls.Rescan(rescanRoot, current) : null)
                      ?? WeModInstalls.FindWeMod(),
                () =>
                {
                    UseInstall(null);
                    Log(LocalizationManager.Get("log_install_not_found"), ELogType.Error);
                });
        }

        private void OnCopyDiagnostics(object param)
        {
            try
            {
                var builder = new StringBuilder();
                builder.AppendLine($"SovereignTitan: {Constants.Version} (build {Constants.Build})");
                builder.AppendLine($"OS: {Environment.OSVersion} | Runtime: {System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription}");
                if (WeModInfo != null)
                {
                    var folderVersion = WeModInstalls.ParseFolderVersion(Path.GetFileName(WeModInfo.RootDirectory));
                    builder.AppendLine($"Install: {WeModInfo.ExecutablePath}");
                    builder.AppendLine($"Client version: {(folderVersion.Major > 0 ? folderVersion.ToString() : "unknown")}");
                    builder.AppendLine($"Patched: {AlreadyPatched} | Backup present: {Enhancer.HasBackup(WeModInfo.RootDirectory)}");
                }
                else
                {
                    builder.AppendLine("Install: none found");
                }

                builder.AppendLine("--- session log ---");
                builder.Append(BuildLogReport());
                ClipboardRetry.SetText(builder.ToString());
                Log(LocalizationManager.Get("log_copied"), ELogType.Success);
            }
            catch (Exception e)
            {
                Log(LocalizationManager.Format("log_copy_failed", e.Message), ELogType.Error);
            }
        }

        private void Log(string message, ELogType logType)
        {
            Action action = () =>
            {
                var entry = new LogEntry
                {
                    LogType = logType,
                    Message = $"[{logType.ToString().ToUpper()}] {message}"
                };
                LogList.Add(entry);
                _shell?.ScrollLogIntoView(entry);
                // Force CanExecute re-evaluation when appending log entries.
                System.Windows.Input.CommandManager.InvalidateRequerySuggested();
            };

            var dispatcher = Application.Current?.Dispatcher;
            if (dispatcher != null && !dispatcher.CheckAccess())
            {
                dispatcher.Invoke(action);
            }
            else
            {
                action();
            }
        }

        public void AppendLog(string message, ELogType logType) => Log(message, logType);

        public void RunDiagnostics()
        {
            if (IsBusy) return;
            IsBusy = true;
            Task.Run(() =>
            {
                try
                {
                    DiagnosticsHelper.RunSystemDiagnostics(WeModInfo, Log);
                }
                finally
                {
                    IsBusy = false;
                }
            });
        }

        public void RunAutoDoctor()
        {
            if (IsBusy) return;
            IsBusy = true;
            Task.Run(() =>
            {
                try
                {
                    AutoDoctorHelper.RunAutoDoctor(WeModInfo, Log);
                }
                finally
                {
                    IsBusy = false;
                }
            });
        }

        public void ConfigureFirewall()
        {
            if (IsBusy) return;
            IsBusy = true;
            Task.Run(() =>
            {
                try
                {
                    FirewallHelper.AddFirewallRule(FirewallHelper.DefaultPort, FirewallHelper.DefaultRuleName, Log);
                }
                finally
                {
                    IsBusy = false;
                }
            });
        }

        private void OnOpenSettings(object param)
        {
            _shell.OpenPopup(new SettingsPopup(), LocalizationManager.Get("settings_title"));
        }

        private string BuildLogReport()
        {
            var builder = new StringBuilder();
            foreach (var entry in LogList)
            {
                builder.AppendLine(entry.Message);
            }
            return builder.ToString();
        }

        private void OnCopyLogs(object param)
        {
            try
            {
                ClipboardRetry.SetText(BuildLogReport());
                Log(LocalizationManager.Get("log_copied"), ELogType.Success);
            }
            catch (Exception e)
            {
                Log(LocalizationManager.Format("log_copy_failed", e.Message), ELogType.Error);
            }
        }

        private void OnExportLogs(object param)
        {
            string path = _dialogs.PickSaveFile(
                LogExportFilter,
                $"sovereign-titan-log-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
            if (path == null)
            {
                return;
            }

            try
            {
                File.WriteAllText(path, BuildLogReport());
                Log(LocalizationManager.Format("log_exported", path), ELogType.Success);
            }
            catch (Exception e)
            {
                Log(LocalizationManager.Format("log_export_failed", e.Message), ELogType.Error);
            }
        }

        private bool HasLogs(object param) => LogList.Count > 0;

        /// <summary>Displays the repository URL if the browser fails to open.</summary>
        public void ReportRepositoryLinkFailure(string url)
        {
            Log(LocalizationManager.Format("log_open_link_failed", url), ELogType.Warn);
        }

        public MainWindowVm(IShellView shell, IFileDialogs dialogs)
        {
            _shell = shell;
            _dialogs = dialogs;
            SetFolderPathCommand = new RelayCommand(OnFolderPathSelection, _ => IsIdle);
            ApplyPatchCommand = new RelayCommand(OnPatching, _ => IsPatchEnabled && IsIdle);
            RestoreBackupCommand = new RelayCommand(OnBackupRestoring, _ => CanRestore && IsIdle);
            OpenSettingsCommand = new RelayCommand(OnOpenSettings, _ => IsIdle);
            CopyLogsCommand = new RelayCommand(OnCopyLogs, HasLogs);
            ExportLogsCommand = new RelayCommand(OnExportLogs, HasLogs);
            ConfigureFirewallCommand = new RelayCommand(_ => ConfigureFirewall(), _ => IsIdle);
            RunDiagnosticsCommand = new RelayCommand(_ => RunDiagnostics(), _ => IsIdle);
            RunAutoDoctorCommand = new RelayCommand(_ => RunAutoDoctor(), _ => IsIdle);
            CopyDiagnosticsCommand = new RelayCommand(OnCopyDiagnostics);
            RescanInstallCommand = new RelayCommand(OnRescanInstall, _ => IsIdle);

            var saved = SettingsManager.LoadSettings();
            var resolved = !string.IsNullOrEmpty(saved?.LastInstallPath)
                ? WeModInstalls.ResolveInstall(saved.LastInstallPath)
                : null;
            UseInstall(resolved ?? WeModInstalls.FindWeMod());
            if (WeModInfo == null)
            {
                Log(LocalizationManager.Get("log_install_not_found"), ELogType.Error);
            }

            foreach (var entry in Program.StartupLog)
            {
                Log(entry.Key, entry.Value);
            }
            Program.StartupLog.Clear();

#if ENABLE_UPDATE_NOTIFICATIONS
            ShowUpdateCommand = new RelayCommand(OnShowUpdate);
            UpdateNotifier.CheckInBackground(OnUpdateFound, OnNotificationClick);
#endif
        }

#if ENABLE_UPDATE_NOTIFICATIONS
        private UpdateNotifier.UpdateRelease _availableUpdate;
        private bool _isUpdateAvailable;

        public bool IsUpdateAvailable
        {
            get => _isUpdateAvailable;
            private set => SetProperty(ref _isUpdateAvailable, value);
        }

        public RelayCommand ShowUpdateCommand { get; }

        private void OnShowUpdate(object param)
        {
            if (_availableUpdate != null)
                OpenUpdatePopup(_availableUpdate);
        }

        private void OnUpdateFound(UpdateNotifier.UpdateRelease update)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                _availableUpdate = update;
                IsUpdateAvailable = true;
            });
        }

        private void OnNotificationClick(UpdateNotifier.UpdateRelease update)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                var window = Application.Current.MainWindow;
                if (window != null)
                {
                    window.Topmost = true;
                    window.Activate();
                    window.Topmost = false;
                }

                OpenUpdatePopup(update);
            });
        }

        private void OpenUpdatePopup(UpdateNotifier.UpdateRelease update)
        {
            _shell.OpenPopup(
                new UpdatePopup(Constants.Version.ToString(), update.Version, update.Notes,
                    update.Url, UpdateNotifier.GetFullChangelogAsync),
                LocalizationManager.Get("up_popup_title"));
        }
#endif
    }
}
