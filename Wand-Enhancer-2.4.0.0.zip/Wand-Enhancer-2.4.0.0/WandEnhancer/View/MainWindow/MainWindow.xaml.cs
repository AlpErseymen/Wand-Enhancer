using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using WandEnhancer.Core;

namespace WandEnhancer.View.MainWindow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : IShellView
    {
        public static MainWindow Instance;
        public readonly MainWindowVm ViewModel;

        public MainWindow()
        {
            InitializeComponent();
            if (Core.Services.LocalizationManager.CurrentLanguage?.TextInfo.IsRightToLeft == true)
            {
                this.FlowDirection = FlowDirection.RightToLeft;
            }
            this.ViewModel = new MainWindowVm(this, new WindowsFileDialogs());
            this.DataContext = ViewModel;
            VersionLabel.Text = Constants.Version.ToString();
            Instance = this;

            LauncherLog.Write("SECURITY ADVISORY: Only run official binaries verified with SHA256 from Eng. Abdelrahman Rashad (@abdelrahmanayman722-ops). Beware of malicious typosquats (@ki11tbyte, ki1bytee, smokeysfc) distributing password-stealing malware.", ELogType.Info);
            ViewModel.AppendLog("SECURITY: Verify official SHA256 hashes published by @abdelrahmanayman722-ops.", ELogType.Info);
        }

        public void OpenPopup(FrameworkElement content, string title = null)
        {
            this.PopupHost.PopupContent = content;
            PopupHost.Title.Text = title;
            PopupHost.IsOpen = true;
        }

        public void ScrollLogIntoView(LogEntry entry)
        {
            this.LogList.ScrollIntoView(entry);
        }

        private void OnDragMove(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void OnClosing(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        public void ClosePopup()
        {
            PopupHost.IsOpen = false;
        }

        private void OpenSourceClicked(object sender, MouseButtonEventArgs e)
        {
            // Try to open link, do not crash if it fails.
            try
            {
                System.Diagnostics.Process.Start(Constants.RepositoryUrl);
            }
            catch (Exception)
            {
                ViewModel.ReportRepositoryLinkFailure(Constants.RepositoryUrl);
            }
        }

        private void OnWindowDragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
                e.Handled = true;
            }
            else
            {
                e.Effects = DragDropEffects.None;
            }
        }

        private void OnWindowDrop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;

            var files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files != null && files.Length > 0)
            {
                string droppedPath = files[0];
                if (System.IO.File.Exists(droppedPath))
                {
                    droppedPath = System.IO.Path.GetDirectoryName(droppedPath);
                }

                if (System.IO.Directory.Exists(droppedPath))
                {
                    ViewModel?.SetCustomInstallPath(droppedPath);
                }
            }
        }
    }
}